Decisiones que he tomado al hacer el examen:
-El enunciado del examen no me ha dejado claro si un cust puede tener asociado m�s de un newspaper (Deja claro que un newspaper tiene m�s de un cust, pero no si un cust puede tener varios). 
Le he visto el sentido que solo pueda tener uno asociado porque si se pudieran asociar a varios la descripcion y el titulo perder�a el sentido. De la forma que lo he implementado puedes guardarlo en modo
draft con o sin newspaper asociado, pero para guardarlo en modo final te obliga a asociarle un newspaper.
-El tema de los colores tampoco me ha quedado claro, porque tal y como est� en el enunciado se interpreta que todo el cust deber�a aparecer coloreado, pero con los colores que te dan (en especial el negro) no
se ve�a nada al hacer display. Es por esto que he optado a "colorear" tan solo la columna donde aparece los gauges.